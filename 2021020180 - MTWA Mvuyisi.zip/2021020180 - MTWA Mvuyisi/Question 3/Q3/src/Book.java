
public class Book implements LibraryInterface {
    private String Title;
    private String Author;
    private boolean isCheckedOut;
    
    public Book(String Title, String Author){
        this.Title=Title;
        this.Author=Author;
        this.isCheckedOut=false;
        
    }
    
    @Override
    public void checkOut(){
        if(!isCheckedOut){
            isCheckedOut=true;
            System.out.println("Book " + Title + " by " + Author + " has been checked out.");
        } 
        else
        {
            System.out.println("Book " + Title + " by " + Author + " is already checked out.");
        }
    }
    
    @Override
    public void returnLibItem(){
        if(isCheckedOut){
            isCheckedOut=false;
            System.out.println("Book " + Title + " by " + Author + " has been returned out.");
        }
        else
        {
            System.out.println("Book " + Title + " by " + Author + " was not checked out.");
        }
    }
    
    public String getTitle(){
        return Title;
    }
    
    public String getAuthor(){
        return Author;
    }
    
    public boolean isCheckedOut(){
        return isCheckedOut;
    }
}
