
public interface LibraryInterface {
    void checkOut();    //checks out
    void returnLibItem();   //for returning the library book or journal
    
}
