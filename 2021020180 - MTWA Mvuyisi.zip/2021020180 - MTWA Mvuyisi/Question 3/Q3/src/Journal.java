
public class Journal implements LibraryInterface{
    public String title;
    public int volume;
    public boolean isCheckedOut;
    
    public Journal(String title, int volume){
        this.title=title;
        this.volume=volume;
        this.isCheckedOut=false;
    }
    
    @Override
    public void checkOut(){
        if(!isCheckedOut){
            isCheckedOut = true;
            System.out.println("Journal " + title + ", Volume " + volume + " has been checked out");
        }
        else
        {
            System.out.println("Journal " + title + ", Volume " + volume + " is already checked out");
        }
    }
    
    @Override
    public void returnLibItem(){
        if(isCheckedOut){
            isCheckedOut = true;
            System.out.println("Journal " + title + ", Volume " + volume + " has been returned.");
        }
        else
        {
            System.out.println("Journal " + title + ", Volume " + volume + " was not checked out.");
        }
    }
    
    public String getTitle(){
        return title;
    }
    
    public int getVolume(){
        return volume;
    }
    
    public boolean isCheckedOut(){
        return isCheckedOut;
    }
}
