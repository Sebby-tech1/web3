import java.util.*;
public class Main {

    public static void main(String[] args) {
        Scanner objscanner = new Scanner(System.in);
        
        //sample books and journals
        Book book1 = new Book("Think and Grow Rich","Napolean Hill");
        Book book2 = new Book("Capitalist Nigger","Chika Onyeani");
        Journal journal1 = new Journal("Science",2021);
        Journal journal2 = new Journal("Biology",2000);
        
        while(true){    //use of a while loop for continuous calculations and handles exception to manage errors
            System.out.println("\nLibrary Management System:");
            System.out.println("1. Check Out Book");
            System.out.println("2. Return Book");
            System.out.println("3. Check Out Journal");
            System.out.println("4. Return Journal");
            System.out.println("5. Exit");
            System.out.println("Enter your choice: ");
            int choice = objscanner.nextInt();  
            objscanner.nextLine();  //consume newline
            
            switch(choice){
                case 1:
                    System.out.println("Available books to check out:");
                    System.out.println("1. "+book1.getTitle()+" by "+book1.getAuthor());
                    System.out.println("2. "+book2.getTitle()+" by "+book2.getAuthor());
                    System.out.println("Choose a book (1-2): ");
                    int bookChoice = objscanner.nextInt();
                    if(bookChoice == 1){
                        book1.checkOut();
                    }
                    else if(bookChoice == 2)
                    {
                        book2.checkOut();
                    }
                    else
                    {
                        System.out.println("Invalid choice.");
                    }
                    break;
                    
                    case 2:
                    System.out.println("Checked out books to return:");
                    System.out.println("1. "+book1.getTitle()+" by "+book1.getAuthor());
                    System.out.println("2. "+book2.getTitle()+" by "+book2.getAuthor());
                    System.out.println("Choose a book to return (1-2): ");
                    bookChoice = objscanner.nextInt();
                    if(bookChoice == 1){
                        book1.returnLibItem();
                    }
                    else if(bookChoice == 2)
                    {
                        book2.returnLibItem();
                    }
                    else
                    {
                        System.out.println("Invalid choice.");
                    }
                    break;
                    
                    case 3:
                    System.out.println("Available journals to check out:");
                    System.out.println("1. "+journal1.getTitle()+" by "+journal1.getVolume());
                    System.out.println("2. "+book2.getTitle()+" by "+book2.getAuthor());
                    System.out.println("Choose a Journal (1-2): ");
                    int JournalChoice = objscanner.nextInt();
                    if(JournalChoice == 1){
                        journal1.checkOut();
                    }
                    else if(JournalChoice == 2)
                    {
                        journal2.checkOut();
                    }
                    else
                    {
                        System.out.println("Invalid choice.");
                    }
                    break;
                    
                    case 4:
                    System.out.println("Checked Out journals to return:");
                    System.out.println("1. "+journal1.getTitle()+" by "+journal1.getVolume());
                    System.out.println("2. "+journal2.getTitle()+" by "+journal2.getVolume());
                    System.out.println("Choose a Journal to return (1-2): ");
                    JournalChoice = objscanner.nextInt();
                    if(JournalChoice == 1){
                        journal1.returnLibItem();
                    }
                    else if(JournalChoice == 2)
                    {
                        journal2.returnLibItem();
                    }
                    else
                    {
                        System.out.println("Invalid choice.");
                    }
                    break;
                    
                    case 5:
                        System.out.println("Exiting Library Management System.");
                        objscanner.close();
                        return;
                    default:
                        System.out.println("Invalid choice. Try again");
            }
        }
    }
    
}
