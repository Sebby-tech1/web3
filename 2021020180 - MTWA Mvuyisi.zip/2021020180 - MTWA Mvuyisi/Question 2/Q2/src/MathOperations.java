

public class MathOperations {
    //method for addition
    public double add(double x, double y){
        return x + y;   // returns the calculation
    }
    
    //method for subtraction
    public double subtract(double x, double y){
        return x - y;   // returns the calculation
    }
    
    //method for multiplication
    public double multiply(double x, double y){
        return x * y;   // returns the calculation
    }
    
    //method for division
    public double divide(double x, double y){
        if(y==0){   //introduction of if statement because any number divided by zero = undefined.
            throw new ArithmeticException("Cannot divide by zero");
        }
        return x / y;   // returns the calculation
    }
    
    //method for modulus
    public double modulus(double x, double y){
        return x % y;   // returns the calculation
    }
    
    //method for asquare root
    public double sqrt(double x, double y){
       if(x < 0){   //introduction of if statements again because there is no square root of zero
           throw new ArithmeticException("Cannot take square root of a negative number");
       }
       return Math.sqrt(x); // returns the calculation
    }
}
