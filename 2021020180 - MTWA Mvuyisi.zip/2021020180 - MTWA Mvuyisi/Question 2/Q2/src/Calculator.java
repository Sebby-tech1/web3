import java.util.*;
public class Calculator {   //This is the main class which executes the code.

    public static void main(String[] args) {
        Scanner objscanner = new Scanner(System.in);
        MathOperations operations = new MathOperations();
        boolean continueCalculation = true;
        
        while(continueCalculation){ //use of a while loop for continuous calculations and handles exception to manage errors
            System.out.println("Select an Operation: ");
            System.out.println("1. Addition");
            System.out.println("2. Subtraction");
            System.out.println("3. Multiplication");
            System.out.println("4. Division");
            System.out.println("5. Modulus");
            System.out.println("6. Square Root");
            System.out.println("Enter your choice (1-6): ");
            int choice = objscanner.nextInt();
            
            double num1=0, num2=0;
            if(choice >= 1 && choice <= 5){
                System.out.println("Enter first number: ");
                num1=objscanner.nextDouble();
                System.out.println("Enter second number: ");
                num2=objscanner.nextDouble();
            } else if(choice == 6){
                System.out.println("Enter number: ");
                num1=objscanner.nextDouble();
            }
            try {
                switch (choice){    //switch case for doing all the operations needed
                    case 1:
                        System.out.println("Result: "+ operations.add(num1, num2));
                        break;
                        
                    case 2:
                        System.out.println("Result: "+ operations.subtract(num1, num2));
                        break;
                    
                    case 3:
                        System.out.println("Result: "+ operations.multiply(num1, num2));
                        break;
                        
                    case 4:
                        System.out.println("Result: "+ operations.divide(num1, num2));
                        break;
                        
                    case 5:
                        System.out.println("Result: "+ operations.modulus(num1, num2));
                        break;
                        
                    case 6:
                        System.out.println("Result: "+ operations.sqrt(num1, num2));
                        break;
                        
                    default:
                        System.out.println("Invalid choice!");  //if neither of the above operations were selected, this message will show
                        break;
                }
            }catch (ArithmeticException e){
                System.out.println("Error: "+ e.getMessage());
            }
            System.out.println("Do you want to perform another calculation? (y/n): ");
            char continueChoice = objscanner.next().charAt(0);
            if(continueChoice == 'n' || continueChoice == 'N'){ //for terminating the calculation
            continueCalculation = false;
        }
        }
        System.out.println("Calculator Program has ended.");    //displays this message at the end of a calculation
        objscanner.close();
    }
    
}
