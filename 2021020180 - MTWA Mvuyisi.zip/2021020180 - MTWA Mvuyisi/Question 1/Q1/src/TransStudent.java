
public class TransStudent extends Student{  //inherits from the parent class Student
    private String previousInstitution;
    
    public TransStudent(String studentID, String firstName, String lastName, String previousInstitution){
        super(studentID, firstName, lastName);//super keyword is used to call superclass methods and access the superclass constructor
        this.previousInstitution=previousInstitution;
    }
    
    @Override //ensures that a virtual function in a derived class correctly overrides a virtual function in base class
    public void displayDetails(){
        super.displayDetails();
        System.out.println("Previous Institution: "+previousInstitution);
        
    }
}
