
public class IntStudent extends Student{    //inherits from the parent class Student
    private String countryOfOrigin;
    private String passportNumber;
    
    public IntStudent(String studentID, String firstName, String lastName, String countryOfOrigin, String passportNumber){
        super(studentID, firstName, lastName); //super keyword is used to call superclass methods and access the superclass constructor 
        this.countryOfOrigin=countryOfOrigin;
        this.passportNumber=passportNumber;
    }
    
    @Override //ensures that a virtual function in a derived class correctly overrides a virtual function in base class
    public void displayDetails(){
        super.displayDetails();
        System.out.println("Country Of Origin: " + countryOfOrigin);
        System.out.println("Passport Number: " + passportNumber);
    }
}
