
public class Student {
    protected String studentID;
    protected String firstName;
    protected String lastName;
    
    //Creating constructors to initialize attribute above
    public Student(String studentID, String firstName, String lastName){
        this.studentID=studentID;//this keyword is a referencw to the current object
        this.firstName=firstName;
        this.lastName=lastName;
    }
    
    //void function for displaying attributes 
    public void displayDetails(){
        System.out.println("Student ID: "+ studentID);
        System.out.println("First Name: "+ firstName);
        System.out.println("Last Name: "+ lastName);
    }
    
}
