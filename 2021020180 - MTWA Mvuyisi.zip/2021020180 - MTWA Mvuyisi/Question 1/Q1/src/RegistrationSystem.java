import java.util.ArrayList; //implements the functionality of resizable-arrays
import java.util.InputMismatchException; //prompts users for input using scanner class with the exception of when the input is invalid for the expected type
import java.util.*; //reads input data from different sources

// This is the main class which executes the code 

public class RegistrationSystem {
    private ArrayList<Student> students;
    
    public RegistrationSystem(){
        students = new ArrayList<>();
    }
    
    public void addStudent(Student student){
        students.add(student);
        System.out.println("Student added successfully!");
    }
    
    public void displayAllStudents(){
        if(students.isEmpty()){ //use of if statements since there could be more than results
            System.out.println("No students registered.");
        } else {
            for (Student student : students) {
                student.displayDetails();
                System.out.println();
            }
        }
    }
    public static void main(String[] args) {
        RegistrationSystem system = new RegistrationSystem();
        Scanner objscanner = new Scanner(System.in);
        boolean exit = false;
        
        while(!exit){   //Use of a while loop for continuous calculations
            try {   //use try so that the code doesn't crash if the desired result is not met after a lot of tries
                System.out.println("1. Add Regular Student");
                System.out.println("2. Add Transfer Student");
                System.out.println("3. Add International Student");
                System.out.println("4. Display All Student");
                System.out.println("5. Exit");
                System.out.println("Enter your choice: ");
                int choice = objscanner.nextInt();
                objscanner.nextLine(); //consume newline
                
                switch(choice){ //since we are dealing with a lot of scenarios, switch is more ideal in this case
                    case 1:
                        System.out.print("Enter Student ID: ");
                        String regiID = objscanner.nextLine();
                        System.out.print("Enter First Name: ");
                        String regiFirstName = objscanner.nextLine();
                        System.out.print("Enter Last Name: ");
                        String regiLastName = objscanner.nextLine();
                        System.out.print("Enter Year Level: ");
                        int YearLevel = objscanner.nextInt();
                        objscanner.nextLine(); //consume newline
                        System.out.print("Enter Specialization: ");
                        String specialization = objscanner.nextLine();
                        system.addStudent(new RegStudent(regiID, regiFirstName, regiLastName, YearLevel, specialization));
                        break;
                        
                        case 2:
                        System.out.print("Enter Student ID: ");
                        String tranID = objscanner.nextLine();
                        System.out.print("Enter First Name: ");
                        String tranFirstName = objscanner.nextLine();
                        System.out.print("Enter Last Name: ");
                        String tranLastName = objscanner.nextLine();
                        System.out.print("Enter Previous Institution: ");
                        String previousInstitution = objscanner.nextLine();
                        system.addStudent(new TransStudent(tranID, tranFirstName, tranLastName,previousInstitution));
                        break;
                        
                        case 3:
                        System.out.print("Enter Student ID: ");
                        String intID = objscanner.nextLine();
                        System.out.print("Enter First Name: ");
                        String intFirstName = objscanner.nextLine();
                        System.out.print("Enter Last Name: ");
                        String intLastName = objscanner.nextLine();
                        System.out.print("Enter Country Of Origin: ");
                        String countryOfOrigin = objscanner.nextLine();
                        System.out.print("Enter Passport Number: ");
                        String passportNumber = objscanner.nextLine();
                        system.addStudent(new IntStudent(intID, intFirstName, intLastName, countryOfOrigin, passportNumber));
                        break;
                        
                        case 4:
                            system.displayAllStudents();
                            break;
                           
                        case 5:
                            exit = true;
                            break;
                            
                        default:
                            System.out.println("Invalid choice. Please try again.");
                }
            } catch(InputMismatchException e) { //catches the desired result
                System.out.println("Invalid input. Please enter the correct data type.");
                objscanner.nextLine(); //consume invalid input
            }
        }
    objscanner.close();
    }
    
}
