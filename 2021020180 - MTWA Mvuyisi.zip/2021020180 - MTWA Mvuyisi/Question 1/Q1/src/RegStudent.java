
public class RegStudent extends Student{    //inherits from the parent class Student
    private int yearLevel;
    private String specialization;
    
    public RegStudent(String studentID, String firstName, String lastName, int yearLevel, String specialization){
        super(studentID, firstName, lastName);//super keyword is used to call superclass methods and access the superclass constructor
        this.yearLevel=yearLevel;
        this.specialization=specialization;
    }
    
    @Override   //ensures that a virtual function in a derived class correctly overrides a virtual function in base class
    public void displayDetails(){
        super.displayDetails();
        System.out.println("Year Level: " + yearLevel);
        System.out.println("Specialization: " + specialization);
    }
}
